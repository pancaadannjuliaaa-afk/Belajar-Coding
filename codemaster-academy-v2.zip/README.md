# CodeMaster Academy V2

Tahap 2: buku pembelajaran interaktif.

## Yang ditambahkan
- 10 learning track: HTML, CSS, JavaScript, Python, Ruby, PHP, C++, Java, SQL, Cyber Security.
- 10 bab terstruktur pada setiap track.
- Konsep, alasan, contoh kode, langkah memahami, tips, latihan, quiz, dan project.
- Progress per bab disimpan di localStorage.
- Reading progress bar.
- Playground HTML/CSS/JavaScript.
- Jadwal shalat berbasis koordinat melalui Vercel serverless API.
- Notifikasi browser dan audio adzan (butuh file `assets/audio/adhan.mp3` milikmu).
- Responsive mobile/desktop.
- Hero artwork.

## Jalankan
```bash
npm i -g vercel
vercel dev
```

## Deploy
Import folder ini ke Vercel atau push ke GitHub lalu import repository.

## WhatsApp
Edit URL `https://wa.me/6280000000000` di `app.js`.

## Tahap berikutnya
Untuk menjadi platform kursus produksi penuh, tahap berikutnya sebaiknya memindahkan materi ke Markdown/JSON terpisah atau CMS/database, menambahkan login, sinkronisasi progress server, sertifikat, search, bookmark, dan lebih banyak bab/project.
